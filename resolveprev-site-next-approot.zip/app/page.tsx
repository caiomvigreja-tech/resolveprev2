import ResolvePrevLanding from "@/components/ResolvePrevLanding";

export default function Page() {
  return <ResolvePrevLanding />;
}
