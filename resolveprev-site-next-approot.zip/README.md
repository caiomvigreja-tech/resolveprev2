# ResolvePrev – Next.js (App Router) + Tailwind

Estrutura com `app/` na raiz (compatível com a detecção da Vercel).

## Rodar localmente
```bash
npm install
npm run dev
```

## Deploy na Vercel
- Importe o repositório.
- Build: `next build`
- Output: `.next`
